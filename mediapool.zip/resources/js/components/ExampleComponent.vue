<template>
    <div class="container">
        <ContactForm></ContactForm>
    </div>
</template>

<script>
export default {
    mounted() {
        console.log("Component mounted.");
    }
};
</script>
